using Microsoft.AspNetCore.Mvc;
using eTdsWeb.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace eTdsWeb.Controllers
{
    public class ChallanController : Controller
    {
        // Mock Data Store
        private static List<Challan> _challans = new List<Challan>();

        public IActionResult Index()
        {
            return View(_challans);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(Challan challan)
        {
            if (ModelState.IsValid)
            {
                if (!ValidateChallan(challan))
                {
                    return View(challan);
                }

                challan.Id = _challans.Count + 1;
                _challans.Add(challan);
                return RedirectToAction("Index");
            }
            return View(challan);
        }

        public IActionResult Edit(int id)
        {
            var challan = _challans.FirstOrDefault(c => c.Id == id);
            if (challan == null) return NotFound();
            return View(challan);
        }

        [HttpPost]
        public IActionResult Edit(Challan challan)
        {
            if (ModelState.IsValid)
            {
                if (!ValidateChallan(challan))
                {
                    return View(challan);
                }

                var existing = _challans.FirstOrDefault(c => c.Id == challan.Id);
                if (existing != null)
                {
                    _challans.Remove(existing);
                    _challans.Add(challan);
                    _challans = _challans.OrderBy(c => c.Id).ToList();
                }
                return RedirectToAction("Index");
            }
            return View(challan);
        }

        public IActionResult Delete(int id)
        {
            var challan = _challans.FirstOrDefault(c => c.Id == id);
            if (challan != null)
            {
                _challans.Remove(challan);
            }
            return RedirectToAction("Index");
        }

        private bool ValidateChallan(Challan model)
        {
            bool isValid = true;

            if (model.BookEntry == "Y")
            {
                if (!string.IsNullOrEmpty(model.BSRCode))
                {
                    ModelState.AddModelError("BSRCode", "BSR Code must be blank for Book Entry");
                    isValid = false;
                }
            }
            else
            {
                if (string.IsNullOrEmpty(model.BSRCode) && model.NilChallanIndicator == "N")
                {
                    ModelState.AddModelError("BSRCode", "BSR Code is required");
                    isValid = false;
                }
                
                if (model.DepositDate.HasValue && model.DepositDate.Value > DateTime.Now)
                {
                     ModelState.AddModelError("DepositDate", "Date cannot Exceed the System Date");
                     isValid = false;
                }
            }
            
            decimal totalTax = model.TdsAmount + model.Surcharge + model.EducationCess + model.Interest + model.Others;
            if (model.NilChallanIndicator == "N" && totalTax == 0)
            {
                 ModelState.AddModelError("TdsAmount", "Total Tax Deposited Cannot be 0");
                 isValid = false;
            }

            // Logic from procValidateIntAllocOtherAmt
            // Assuming "Allocatable Amt" calculation roughly: Total Deposited - TDS
            // The VB logic was complex (Val(TOt) - Val(TOtDed)), implying checking against utilized amount.
            // Simplified check: Allocated amounts shouldn't exceed the total Challan amount for now.
            if (model.InterestAllocated + model.OtherAmountAllocated > totalTax)
            {
                ModelState.AddModelError("InterestAllocated", "Allocated amount cannot be greater than Total Tax Deposited");
                isValid = false;
            }

            return isValid;
        }
    }
}
