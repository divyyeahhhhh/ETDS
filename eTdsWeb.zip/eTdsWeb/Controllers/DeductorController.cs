using Microsoft.AspNetCore.Mvc;
using eTdsWeb.Models;
using System.Text.RegularExpressions;
using System.Collections.Generic;

namespace eTdsWeb.Controllers
{
    public class DeductorController : Controller
    {
        // Mock Data Store
        private static Deductor _currentDeductor = new Deductor
        {
            CompanyName = "Test Company",
            TAN = "ABCD12345E",
            Status = "K", // Company
            State = "MAHARASHTRA"
        };

        [HttpGet]
        public IActionResult Edit()
        {
            return View(_currentDeductor);
        }

        [HttpPost]
        public IActionResult Edit(Deductor model)
        {
            if (ModelState.IsValid)
            {
                // Custom Validation Logic migrated from VB
                if (!ValidateDeductor(model))
                {
                    return View(model);
                }

                _currentDeductor = model;
                ViewBag.Message = "Records Updated Successfully";
                return View(model);
            }
            return View(model);
        }

        private bool ValidateDeductor(Deductor model)
        {
            bool isValid = true;

            // PAO Code Validation
            if (model.Status == "A" && string.IsNullOrWhiteSpace(model.PAOCode))
            {
                ModelState.AddModelError("PAOCode", "PAO Code cannot be empty for Central Govt.");
                isValid = false;
            }

            // DDO Code Validation
            if (model.Status == "A" && string.IsNullOrWhiteSpace(model.DDOCode))
            {
                ModelState.AddModelError("DDOCode", "DDO Code cannot be empty for Central Govt.");
                isValid = false;
            }

            // Ministry Validation
            if ((model.Status == "A" || model.Status == "D" || model.Status == "G") && string.IsNullOrWhiteSpace(model.Ministry))
            {
                ModelState.AddModelError("Ministry", "Ministry cannot be empty.");
                isValid = false;
            }

            // PAN Validation
            if (!string.IsNullOrEmpty(model.PAN) && !ValidatePAN(model.PAN))
            {
                ModelState.AddModelError("PAN", "Invalid PAN.");
                isValid = false;
            }

            if (!string.IsNullOrEmpty(model.GSTN) && !ValidateGSTN(model.GSTN))
            {
                ModelState.AddModelError("GSTN", "Enter valid Goods and Services Tax Number [GSTN]");
                isValid = false;
            }

            return isValid;
        }

        private bool ValidatePAN(string pan)
        {
            if (pan.Length != 10) return false;
            if (pan.ToUpper() == "PANNOTREQD") return true;
            
            string pattern = @"^[A-Z]{5}[0-9]{4}[A-Z]{1}$";
            return Regex.IsMatch(pan, pattern, RegexOptions.IgnoreCase);
        }

        private bool ValidateGSTN(string gstn)
        {
             // Basic regex for GSTN: 2 digits, 5 letters, 4 digits, 1 letter, 1 number/letter, 1 letter, 1 number/letter
             // Simplified for this example
             if (gstn.Length != 15) return false;
             return Regex.IsMatch(gstn, @"^[0-9A-Z]+$");
        }

        private List<string> GetStates()
        {
            return new List<string> {
                "ANDAMAN AND NICOBAR ISLANDS", "ANDHRA PRADESH", "ARUNACHAL PRADESH", "ASSAM", "BIHAR",
                "CHANDIGARH", "DADRA & NAGAR HAVELI", "DAMAN & DIU", "DELHI", "GOA", "GUJARAT",
                "HARYANA", "HIMACHAL PRADESH", "JAMMU & KASHMIR", "KARNATAKA", "KERALA", "MAHARASHTRA",
                "TAMILNADU", "UTTAR PRADESH", "WEST BENGAL"
            };
        }
    }
}
