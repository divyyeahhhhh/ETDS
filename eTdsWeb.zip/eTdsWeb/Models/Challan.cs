using System;
using System.ComponentModel.DataAnnotations;

namespace eTdsWeb.Models
{
    public class Challan
    {
        public int Id { get; set; } // Period/Serial No equivalent

        [Display(Name = "TDS/TCS Code")]
        public string TdsCode { get; set; }

        [Display(Name = "Amount Deposited")]
        public decimal AmountDeposited { get; set; }

        [Display(Name = "Date of Deposit")]
        [DataType(DataType.Date)]
        public DateTime? DepositDate { get; set; }

        [Display(Name = "Challan Serial No")]
        public string ChallanSerialNo { get; set; }

        [Display(Name = "BSR Code")]
        [StringLength(7)]
        public string BSRCode { get; set; }

        [Display(Name = "TDS Amount")]
        public decimal TdsAmount { get; set; }

        [Display(Name = "Surcharge")]
        public decimal Surcharge { get; set; }

        [Display(Name = "Education Cess")]
        public decimal EducationCess { get; set; }

        [Display(Name = "Interest")]
        public decimal Interest { get; set; }

        [Display(Name = "Others")]
        public decimal Others { get; set; }

        [Display(Name = "Cheque/DD No")]
        public string ChequeNumber { get; set; }

        [Display(Name = "Nil Challan Indicator")]
        public string NilChallanIndicator { get; set; } // Y or N

        [Display(Name = "Book Entry")]
        public string BookEntry { get; set; } // Y or N

        [Display(Name = "Transfer Voucher No")]
        public string TransferVoucherNo { get; set; }

        [Display(Name = "Interest Allocated")]
        public decimal InterestAllocated { get; set; }

        [Display(Name = "Other Amount Allocated")]
        public decimal OtherAmountAllocated { get; set; }
        
        public string MatchingIndicator { get; set; }
    }
}
