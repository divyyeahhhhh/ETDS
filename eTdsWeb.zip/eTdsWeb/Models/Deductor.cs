using System;
using System.ComponentModel.DataAnnotations;

namespace eTdsWeb.Models
{
    public class Deductor
    {
        // Company/Deductor Details
        [Display(Name = "GSTN")]
        [StringLength(15)]
        public string GSTN { get; set; }

        [Display(Name = "TAN")]
        [Required]
        [StringLength(10)]
        public string TAN { get; set; }

        [Display(Name = "Company Name")]
        [Required]
        [StringLength(75)]
        public string CompanyName { get; set; }

        [Display(Name = "Branch/Division")]
        [StringLength(75)]
        public string Branch { get; set; }

        [Display(Name = "Address Line 1")]
        [StringLength(25)]
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string Address3 { get; set; }
        public string Address4 { get; set; }
        public string Address5 { get; set; }

        [Display(Name = "State")]
        public string State { get; set; }

        [Display(Name = "PIN Code")]
        [StringLength(6)]
        public string PIN { get; set; }

        [Display(Name = "Email")]
        [EmailAddress]
        public string Email { get; set; }

        [Display(Name = "STD Code")]
        public string StdCode { get; set; }

        [Display(Name = "Phone")]
        public string Phone { get; set; }

        [Display(Name = "Status")]
        public string Status { get; set; }

        [Display(Name = "PAN")]
        [StringLength(10)]
        public string PAN { get; set; }

        // Responsible Person Details
        [Display(Name = "Responsible Person Name")]
        [Required]
        [StringLength(75)]
        public string ResponsiblePersonName { get; set; }

        [Display(Name = "Designation")]
        [StringLength(20)]
        public string Designation { get; set; }

        [Display(Name = "Person Address 1")]
        public string PersonAddress1 { get; set; }
        public string PersonAddress2 { get; set; }
        public string PersonAddress3 { get; set; }
        public string PersonAddress4 { get; set; }
        public string PersonAddress5 { get; set; }

        [Display(Name = "Person State")]
        public string PersonState { get; set; }

        [Display(Name = "Person PIN")]
        public string PersonPIN { get; set; }

        [Display(Name = "Person Email")]
        public string PersonEmail { get; set; }

        [Display(Name = "Person Mobile")]
        public string PersonMobile { get; set; }

        // Government Details
        public string AIN { get; set; }
        public string PAOCode { get; set; }
        public string DDOCode { get; set; }
        public string Ministry { get; set; }
        public string OtherMinistry { get; set; }
        public string PAORegistrationNo { get; set; }
        public string DDORegistrationNo { get; set; }
        public string StateGovtName { get; set; }

        // Alternate Contact Info
        public string AltDeductorEmail { get; set; }
        public string AltDeductorPhone { get; set; }
        public string AltResponsiblePersonEmail { get; set; }
        public string AltResponsiblePersonPhone { get; set; }
        public string ResponsiblePersonPAN { get; set; }

        public bool AddressChanged { get; set; }
    }
}
