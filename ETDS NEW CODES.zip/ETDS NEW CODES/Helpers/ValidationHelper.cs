using System;
using System.Text.RegularExpressions;

namespace EtdsCorrection.Helpers
{
    public static class ValidationHelper
    {
        /// <summary>
        /// Verifies the TAN structure (4 Chars, 5 Digits, 1 Char).
        /// Original VB function: VarifyTan
        /// </summary>
        public static bool VerifyTan(string tan)
        {
            if (string.IsNullOrEmpty(tan) || tan.Length != 10)
                return false;

            // 1-4: Alphabets
            for (int i = 0; i < 4; i++)
            {
                if (char.IsDigit(tan[i])) return false;
            }

            // 5-9: Numerics
            for (int i = 4; i < 9; i++)
            {
                if (!char.IsDigit(tan[i])) return false;
            }

            // 10: Alphabet
            if (char.IsDigit(tan[9])) return false;

            return true;
        }

        /// <summary>
        /// Validates Email ID format.
        /// Original VB function: ValideMailID
        /// </summary>
        public static bool IsValidEmail(string email)
        {
            if (string.IsNullOrWhiteSpace(email)) return false;
            email = email.Trim();

            // Simple check to match legacy logic
            if (email.Contains(" ") || email.Contains("^")) return false;
            if (!email.Contains("@")) return false;
            
            int atIndex = email.IndexOf('@');
            int dotIndex = email.LastIndexOf('.');

            if (dotIndex < atIndex) return false; // Dot must be after @
            if (email.Contains("@.")) return false; // Dot cannot be immediately after @
            if (email.StartsWith("@") || email.StartsWith(".")) return false;

            return true;
        }

        /// <summary>
        /// Validates Certificate Number Pattern (Starts with G or H, followed by numbers).
        /// Original VB function: CertificateNumberPatternForB
        /// </summary>
        public static bool IsValidCertificateNumber(string certNumber)
        {
            if (string.IsNullOrEmpty(certNumber) || certNumber.Length < 2) return false;

            char firstChar = char.ToUpper(certNumber[0]);
            if (firstChar != 'G' && firstChar != 'H') return false;

            for (int i = 1; i < certNumber.Length; i++)
            {
                if (!char.IsDigit(certNumber[i])) return false;
            }

            return true;
        }

        /// <summary>
        /// Checks for special characters.
        /// Original VB function: SpacialCharacterValidate
        /// </summary>
        public static bool ContainsSpecialCharacters(string value)
        {
            if (string.IsNullOrEmpty(value)) return false;
            string specialChars = "`~!@#$%^+ *()_+,./?;:"; // Original list

            foreach (char c in value)
            {
                if (specialChars.Contains(c)) return true;
            }
            return false;
        }

        /// <summary>
        /// Validates GSTN (Length must be 15).
        /// Original VB function: ValidGSTN
        /// </summary>
        public static bool IsValidGSTN(string gstn)
        {
            if (string.IsNullOrEmpty(gstn)) return true; // Original code returns valid if empty?? "If Length > 0 And Length <> 15 Then False"
            return gstn.Length == 15;
        }
        
        /// <summary>
        /// Helper to check empty fields (Replacement for chkEmpty).
        /// </summary>
        public static bool IsEmpty(string text)
        {
            return string.IsNullOrWhiteSpace(text);
        }
    }
}
