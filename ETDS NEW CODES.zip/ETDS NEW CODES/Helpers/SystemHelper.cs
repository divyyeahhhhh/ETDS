using System;
using System.IO;
using System.Net.Http;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace EtdsCorrection.Helpers
{
    public static class SystemHelper
    {
        /// <summary>
        /// Renames .data files based on the Year found in the internal Access database.
        /// Requires System.Data.OleDb and Access Database Engine installed.
        /// Original VB function: RenameOldFiles
        /// </summary>
        public static void RenameOldFiles(string directoryPath)
        {
            // Note: This requires System.Data.OleDb package and Windows environment.
            // Logic:
            // 1. Iterate .data files
            // 2. Open as Access DB with password "Ffcs"
            // 3. Select Year from Parameter table
            // 4. Rename file.
            
            // Implementation skipped as it depends on external ADO/DAO drivers which may not be present in .NET Core context without specific dependencies.
            // To implement, install System.Data.OleDb and use OleDbConnection.
            /*
            var files = Directory.GetFiles(directoryPath, "*.data");
            foreach (var file in files)
            {
                // ... OleDb logic here ...
            }
            */
        }

        /// <summary>
        /// Checks for upgrade via HTTP.
        /// Original VB function: CheckUpgrade
        /// </summary>
        public static async Task<string> CheckUpgradeAsync(string versionUrl, string currentVersion)
        {
            try
            {
                using (var client = new HttpClient())
                {
                    client.Timeout = TimeSpan.FromSeconds(60);
                    var response = await client.GetStringAsync(versionUrl);
                    
                    // Strip HTML if the server returns HTML
                    string serverVersion = StripHTML(response).Trim().Replace(" ", ".");

                    if (double.TryParse(serverVersion, out double sVer) && double.TryParse(currentVersion, out double cVer))
                    {
                        if (sVer > cVer)
                        {
                            return $"You are using Old Version! Please download {serverVersion}";
                        }
                    }
                }
                return "";
            }
            catch (Exception)
            {
                // Original swallowed errors
                return "";
            }
        }

        /// <summary>
        /// Strips HTML tags.
        /// Original VB function: StripHTML (Manual parser)
        /// </summary>
        public static string StripHTML(string input)
        {
            if (string.IsNullOrEmpty(input)) return string.Empty;
            // Use Regex for cleaner implementation
            return Regex.Replace(input, "<.*?>", string.Empty);
        }

        /// <summary>
        /// Changes the System Date Format (Dangerous/Not recommended for Web Apps).
        /// Original VB function: ChangeDate
        /// </summary>
        public static void ChangeDateFormat()
        {
            // This is a system-wide change and typically requires Admin privileges.
            // In a web app, this should NEVER be done.
            // Use CultureInfo for formatting dates instead.
            throw new NotSupportedException("Changing system date format is not supported in this context.");
        }
    }
}
