using System;

namespace EtdsCorrection.Helpers
{
    public static class NumberToWordsHelper
    {
        private static string _currentWord = "";

        public static string ConvertToWords(string numberStr)
        {
            if (string.IsNullOrEmpty(numberStr)) return "";
            
            // Basic cleaning
            string z = numberStr.Trim();
            long val;
            if (!long.TryParse(z, out val)) return "";
            if (val == 0) return "Nil Only"; // Matching Case 0

            string no = "";
            int v = z.Length;

            while (v > 0)
            {
                switch (v)
                {
                    case 11:
                        if (GetVal(z, 2) != 0)
                        {
                            GetNumberWord(GetVal(z, 2));
                            no += _currentWord + " Hundred and";
                            if (GetLong(z.Substring(2)) != 0) z = z.Substring(2);
                            else goto EndLoop;
                        }
                        else z = z.Substring(2);
                        break;

                    case 10:
                        if (GetVal(z, 1) != 0)
                        {
                            GetNumberWord(GetVal(z, 1));
                            no += _currentWord + " Hundred and";
                            if (GetLong(z.Substring(1)) != 0) z = z.Substring(1);
                            else goto EndLoop;
                        }
                        else z = z.Substring(1);
                        break;

                    case 9:
                        if (GetVal(z, 2) != 0)
                        {
                            GetNumberWord(GetVal(z, 2));
                            no += (no.Length > 0 ? " " : "") + _currentWord + " Crore";
                            if (GetLong(z.Substring(2)) != 0) z = z.Substring(2);
                            else goto EndLoop;
                        }
                        else z = z.Substring(2);
                        break;

                    case 8:
                        if (GetVal(z, 1) != 0)
                        {
                            GetNumberWord(GetVal(z, 1));
                            no += (no.Length > 0 ? " " : "") + _currentWord + " Crore";
                            if (GetLong(z.Substring(1)) != 0) z = z.Substring(1);
                            else goto EndLoop;
                        }
                        else z = z.Substring(1);
                        break;

                    case 7:
                        if (GetVal(z, 2) != 0)
                        {
                            GetNumberWord(GetVal(z, 2));
                            no += (no.Length > 0 ? " " : "") + _currentWord + " Lacs";
                            if (GetLong(z.Substring(2)) != 0) z = z.Substring(2);
                            else goto EndLoop;
                        }
                        else z = z.Substring(2);
                        break;

                    case 6:
                        if (GetVal(z, 1) != 0)
                        {
                            GetNumberWord(GetVal(z, 1));
                            no += (no.Length > 0 ? " " : "") + _currentWord + " Lakh";
                            if (GetLong(z.Substring(1)) != 0) z = z.Substring(1);
                            else goto EndLoop;
                        }
                        else z = z.Substring(1);
                        break;

                    case 5:
                        if (GetVal(z, 2) != 0)
                        {
                            GetNumberWord(GetVal(z, 2));
                            no += (no.Length > 0 ? " " : "") + _currentWord + " Thousand";
                            if (GetLong(z.Substring(2)) != 0) z = z.Substring(2);
                            else goto EndLoop;
                        }
                        else z = z.Substring(2);
                        break;

                    case 4:
                        GetNumberWord(GetVal(z, 1));
                        no += (no.Length > 0 ? " " : "") + _currentWord + " Thousand";
                        if (GetLong(z.Substring(1)) != 0) z = z.Substring(1);
                        else goto EndLoop;
                        break;

                    case 3:
                        if (GetVal(z, 1) != 0)
                        {
                            GetNumberWord(GetVal(z, 1));
                            no += (no.Length > 0 ? " " : "") + _currentWord + " Hundred";
                            if (GetLong(z.Substring(1)) != 0) z = z.Substring(1);
                            else goto EndLoop;
                        }
                        else z = z.Substring(1);
                        break;

                    case 2:
                        GetNumberWord(GetVal(z, 2));
                        no += (no.Length > 0 ? " " : "") + _currentWord;
                        break;

                    case 1:
                        GetNumberWord(GetVal(z, 1));
                        no += (no.Length > 0 ? " " : "") + _currentWord;
                        break;
                }

                v = z.Length;
                // Manual decrement logic from VB
                if (v == 7 || v == 5 || v == 9 || v == 11 || v == 2)
                    v = v - 2; // This logic in VB loop is actually weird because z is shortened.
                               // In VB, z is mutated: z = Mid(z, 3). So Len(z) changes.
                               // The Loop condition is `Do While Not v = 0`.
                               // The `Case` logic mutates z.
                               // Then VB has `If v = 7... Then v = v - 2`.
                               // BUT `v` was `Len(z)` at start of loop? No, VB code: `v = Len(z)`. Inside loop: `Select Case v`.
                               // At end of loop: `If v=7... v=v-2`.
                               // BUT `z` was mutated. So `v` should be recalculated?
                               // In VB, `v` is NOT recalculated at start of loop. `v` is used as a state tracker.
                               // But `z` is shortened.
                               // Wait, let's trace VB loop:
                               // `v = Len(z)`
                               // `Do While Not v = 0`
                               //   Case 11: ... `z = Mid(z, 3)` ...
                               //   ...
                               //   `If v = 7 ... Then v = v - 2`
                               //   `ElseIf v = 10 ... Then v = v - 1`
                               // Loop
                               // So `v` tracks the "current logical position" or "remaining digits count" derived from previous step.
                               // Since I am updating `z` and checking `v = z.Length` inside my loop, I don't need the manual `v = v - 2`.
                               // I will trust `z.Length` as the truth.
            }

            EndLoop:
            return no + " Only";
        }

        private static int GetVal(string s, int length)
        {
            if (s.Length < length) return 0;
            if (int.TryParse(s.Substring(0, length), out int result))
                return result;
            return 0;
        }

        private static long GetLong(string s)
        {
            if (long.TryParse(s, out long result)) return result;
            return 0;
        }

        private static void GetNumberWord(int number)
        {
            switch (number)
            {
                case 0: _currentWord = ""; break;
                case 1: _currentWord = "One"; break;
                case 2: _currentWord = "Two"; break;
                case 3: _currentWord = "Three"; break;
                case 4: _currentWord = "Four"; break;
                case 5: _currentWord = "Five"; break;
                case 6: _currentWord = "Six"; break;
                case 7: _currentWord = "Seven"; break;
                case 8: _currentWord = "Eight"; break;
                case 9: _currentWord = "Nine"; break;
                case 10: _currentWord = "Ten"; break;
                case 11: _currentWord = "Eleven"; break;
                case 12: _currentWord = "Twelve"; break;
                case 13: _currentWord = "Thirteen"; break;
                case 14: _currentWord = "Fourteen"; break;
                case 15: _currentWord = "Fifteen"; break;
                case 16: _currentWord = "Sixteen"; break;
                case 17: _currentWord = "Seventeen"; break;
                case 18: _currentWord = "Eighteen"; break;
                case 19: _currentWord = "Nineteen"; break;
                case 20: _currentWord = "Twenty"; break;
                case 21: _currentWord = "Twenty One"; break;
                case 22: _currentWord = "Twenty Two"; break;
                case 23: _currentWord = "Twenty Three"; break;
                case 24: _currentWord = "Twenty Four"; break;
                case 25: _currentWord = "Twenty Five"; break;
                case 26: _currentWord = "Twenty Six"; break;
                case 27: _currentWord = "Twenty Seven"; break;
                case 28: _currentWord = "Twenty Eight"; break;
                case 29: _currentWord = "Twenty Nine"; break;
                case 30: _currentWord = "Thirty"; break;
                case 31: _currentWord = "Thirty One"; break;
                case 32: _currentWord = "Thirty Two"; break;
                case 33: _currentWord = "Thirty Three"; break;
                case 34: _currentWord = "Thirty Four"; break;
                case 35: _currentWord = "Thirty Five"; break;
                case 36: _currentWord = "Thirty Six"; break;
                case 37: _currentWord = "Thirty Seven"; break;
                case 38: _currentWord = "Thirty Eight"; break;
                case 39: _currentWord = "Thirty Nine"; break;
                case 40: _currentWord = "Forty"; break;
                case 41: _currentWord = "Forty One"; break;
                case 42: _currentWord = "Forty Two"; break;
                case 43: _currentWord = "Forty Three"; break;
                case 44: _currentWord = "Forty Four"; break;
                case 45: _currentWord = "Forty Five"; break;
                case 46: _currentWord = "Forty Six"; break;
                case 47: _currentWord = "Forty Seven"; break;
                case 48: _currentWord = "Forty Eight"; break;
                case 49: _currentWord = "Forty Nine"; break;
                case 50: _currentWord = "Fifty"; break;
                case 51: _currentWord = "Fifty One"; break;
                case 52: _currentWord = "Fifty Two"; break;
                case 53: _currentWord = "Fifty Three"; break;
                case 54: _currentWord = "Fifty Four"; break;
                case 55: _currentWord = "Fifty Five"; break;
                case 56: _currentWord = "Fifty Six"; break;
                case 57: _currentWord = "Fifty Seven"; break;
                case 58: _currentWord = "Fifty Eight"; break;
                case 59: _currentWord = "Fifty Nine"; break;
                case 60: _currentWord = "Sixty"; break;
                case 61: _currentWord = "Sixty One"; break;
                case 62: _currentWord = "Sixty Two"; break;
                case 63: _currentWord = "Sixty Three"; break;
                case 64: _currentWord = "Sixty Four"; break;
                case 65: _currentWord = "Sixty Five"; break;
                case 66: _currentWord = "Sixty Six"; break;
                case 67: _currentWord = "Sixty Seven"; break;
                case 68: _currentWord = "Sixty Eight"; break;
                case 69: _currentWord = "Sixty Nine"; break;
                case 70: _currentWord = "Seventy"; break;
                case 71: _currentWord = "Seventy One"; break;
                case 72: _currentWord = "Seventy Two"; break;
                case 73: _currentWord = "Seventy Three"; break;
                case 74: _currentWord = "Seventy Four"; break;
                case 75: _currentWord = "Seventy Five"; break;
                case 76: _currentWord = "Seventy Six"; break;
                case 77: _currentWord = "Seventy Seven"; break;
                case 78: _currentWord = "Seventy Eight"; break;
                case 79: _currentWord = "Seventy Nine"; break;
                case 80: _currentWord = "Eighty"; break;
                case 81: _currentWord = "Eighty One"; break;
                case 82: _currentWord = "Eighty Two"; break;
                case 83: _currentWord = "Eighty Three"; break;
                case 84: _currentWord = "Eighty Four"; break;
                case 85: _currentWord = "Eighty Five"; break;
                case 86: _currentWord = "Eighty Six"; break;
                case 87: _currentWord = "Eighty Seven"; break;
                case 88: _currentWord = "Eighty Eight"; break;
                case 89: _currentWord = "Eighty Nine"; break;
                case 90: _currentWord = "Ninety"; break;
                case 91: _currentWord = "Ninety One"; break;
                case 92: _currentWord = "Ninety Two"; break;
                case 93: _currentWord = "Ninety Three"; break;
                case 94: _currentWord = "Ninety Four"; break;
                case 95: _currentWord = "Ninety Five"; break;
                case 96: _currentWord = "Ninety Six"; break;
                case 97: _currentWord = "Ninety Seven"; break;
                case 98: _currentWord = "Ninety Eight"; break;
                case 99: _currentWord = "Ninety Nine"; break;
                default: _currentWord = ""; break;
            }
        }
    }
}
