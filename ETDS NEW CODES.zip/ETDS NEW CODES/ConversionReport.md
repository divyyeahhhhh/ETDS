# eTds Wizard Conversion Report

## Summary
The core utility module (`eTDsWiz_.txt`) has been successfully converted to C# (ASP.NET Core compatible). Key Models for Deductor and Salary have been scaffolded based on the legacy Forms.

## Converted Components

### 1. Helpers
*   **`ValidationHelper.cs`**: Contains logic for validating TAN, Email, GSTN, and Certificate Numbers.
*   **`NumberToWordsHelper.cs`**: Implements the Indian Numbering System for converting currency/numbers to words (Lakhs/Crores), refactored from the legacy recursive `data`/`Number` functions.
*   **`SystemHelper.cs`**: Utilities for system interaction (HTTP upgrade checks, HTML stripping). Note: Access DB renaming and System Date formatting are flagged as legacy-dependent or unsafe for web apps.

### 2. Services
*   **`MinistryService.cs`**: Replaces the hardcoded `FillMinistry` UI logic with a clean data service returning a list of ministries and codes.

### 3. Models
*   **`DeductorModel.cs`**: Represents the Deductor details (GSTN, Contact info, Status) as inferred from `frmDeductor`.
*   **`SalaryModel.cs`**: Represents a standard Salary TDS record as inferred from `frmSalary`.
*   **`LegacyGlobals.cs`**: Maps the global variables from `Module1`. **Warning**: These are static. In a multi-user web application, these should be scoped per-request or stored in a session/database.

### 4. Legacy Interop
*   **`NativeMethods.cs`**: Contains the P/Invoke declarations for Windows APIs (`user32`, `kernel32`, custom DLLs). These will generally **not work** in a standard Linux/Cloud web environment and are provided for reference or Windows-hosted adaptations.

## Next Steps (Migration Plan)

1.  **Database Migration**: The legacy code uses DAO/ADO to access an Access Database (`.mdb`).
    *   *Action*: Define an Entity Framework Core `DbContext` matching the `Parameter`, `Salary`, `Challan` tables.
    *   *Action*: Migrate data from Access to SQL Server or SQLite.

2.  **UI Conversion (Forms to Views)**:
    *   `frmDeductor` -> `DeductorController` + `Views/Deductor/Index.cshtml` (Edit Form).
    *   `frmSalary` -> `SalaryController` + `Views/Salary/Index.cshtml` (Grid/List) + `Create.cshtml`.
    *   `frmChallanDetails` -> `ChallanController`.

3.  **Business Logic Extraction**:
    *   Extract calculation logic (Tax calc, Validation rules) from the Form `.txt` files (currently mixed with UI code) into Service classes.

## Notes
The folder `ETDSCorrection\Psedudo_Output\Psedudo_Output` contains ~35 other files (Forms/Modules). These require similar analysis and manual conversion to MVC patterns.
