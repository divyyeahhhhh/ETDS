using System;
using System.Runtime.InteropServices;

namespace EtdsCorrection.Legacy
{
    public static class NativeMethods
    {
        // Declare Function InternetGetConnectedState Lib "wininet.dll" (dwFlags, dwReserved)
        [DllImport("wininet.dll")]
        public static extern bool InternetGetConnectedState(out int dwFlags, int dwReserved);

        // Declare Function GetDesktopWindow Lib "user32" ()
        [DllImport("user32.dll")]
        public static extern IntPtr GetDesktopWindow();

        // Declare Function GetSystemDefaultLCID Lib "kernel32" ()
        [DllImport("kernel32.dll")]
        public static extern int GetSystemDefaultLCID();

        // Declare Function SetLocaleInfo Lib "kernel32" Alias "SetLocaleInfoA" (Locale, LCType, lpLCData)
        [DllImport("kernel32.dll", CharSet = CharSet.Ansi)]
        public static extern bool SetLocaleInfoA(int Locale, int LCType, string lpLCData);

        // Declare Function DogRead Lib "Win32dll" (DogBytes, DogAddr, DogData)
        // Likely a custom dongle library. Will fail if DLL not present.
        // [DllImport("Win32dll.dll")]
        // public static extern int DogRead(object DogBytes, object DogAddr, object DogData);

        // Declare Function ShellExecute Lib "shell32.dll" Alias "ShellExecuteA" ...
        [DllImport("shell32.dll", CharSet = CharSet.Ansi)]
        public static extern IntPtr ShellExecuteA(IntPtr hwnd, string lpOperation, string lpFile, string lpParameters, string lpDirectory, int nShowCmd);

        // Declare Function GetLocaleInfo Lib "kernel32" Alias "GetLocaleInfoA" ...
        [DllImport("kernel32.dll", CharSet = CharSet.Ansi)]
        public static extern int GetLocaleInfoA(int Locale, int LCType, System.Text.StringBuilder lpLCData, int cchData);

        // Constants
        public const int LOCALE_SSHORTDATE = 0x1F;
        public const int IDC_HAND = 32649;
        public const int IDC_ARROW = 32512;

        [DllImport("user32.dll")]
        public static extern IntPtr LoadCursorA(IntPtr hInstance, int lpCursorName);

        [DllImport("user32.dll")]
        public static extern IntPtr SetCursor(IntPtr hCursor);

        [DllImport("kernel32.dll", CharSet = CharSet.Ansi)]
        public static extern bool SetCurrentDirectoryA(string lpPathName);

        [DllImport("kernel32.dll", CharSet = CharSet.Ansi)]
        public static extern int GetCurrentDirectoryA(int nBufferLength, System.Text.StringBuilder lpBuffer);

        // CC DLLs - Custom libraries for the application (Copy protection or Encryption?)
        // [DllImport("CCMOVE32.DLL")]
        // public static extern int CCMOVE_SDO(ref object sS, ref object sD, ref object sO, ref object sR, int iSize);

        // [DllImport("CCCHNG32.DLL")]
        // public static extern int CCCHANGE(ref object sPath);

        // [DllImport("CC32.DLL")]
        // public static extern int CC32(ref CCMB CC);

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
        public struct CCMB
        {
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 1)] public string B1;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 1)] public string B2;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 1)] public string B3;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 1)] public string B4;
            public byte Func;
            public byte Rcodelo;
            public byte Rcodehi;
            public byte DriveNo;
            public int Dir; // Check type
            public byte MajorVers;
            public byte MinorVers;
            public short ProductSerialNumber;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 9)] public string ProductCode;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 13)] public string ProgramName;
            public short CCSerialNumber;
            public byte Master;
            public byte DriveType;
            public short Copies;
            public short InitCopies;
            public short Uses;
            public short InitUses;
            public byte ExpiryDay;
            public byte ExpiryMonth;
            public short ExpiryYear;
            public short Feature;
            public short MaxNetUsers;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 257)] public string SecureMsg;
            // ... truncated for brevity, mapping remaining fields requires precise byte alignment
        }
    }
}
