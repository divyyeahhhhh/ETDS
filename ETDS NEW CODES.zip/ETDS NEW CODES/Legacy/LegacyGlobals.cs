using System;

namespace EtdsCorrection.Legacy
{
    // These variables were Global in the VB6 module.
    // In a web environment (ASP.NET), static variables are shared across ALL users (Application Scope).
    // If these are user-specific, they should be moved to Session or a Scoped Service.
    public static class LegacyGlobals
    {
        public static string StrOAccYr;
        public static string StrOFinYr;
        public static string StrOTAN;
        public static string StrRevTAN;
        public static string StrOCName;
        public static string StrOFormNo;
        public static string StrOQtr;
        public static string strTan;
        public static bool blnCancelRETURN;
        public static bool blnSalaryPan;

        public static int mTOtFiles;
        public static string StrRegFile;
        public static string StrRevFile1;
        public static string StrRevFile2;
        public static string StrRevFile3;
        public static string StrRevFile4;
        public static string StrORRRNo;
        public static DateTime mCreatiionDate;
        public static object mDeductorType;
        public static object mYear;
        public static object mStatus;

        public static bool blnTANChgd;
        public static bool blnAddrChgd;
        public static bool blnChlnAddn;
        public static bool blnChlnUpd;
        public static bool blnPANChgd;
        public static bool blnDedChgd;

        public static bool blnC1;
        public static bool blnC2;
        public static bool blnC2BatUpdInd;
        public static bool blnC3;
        public static bool blnC3BatUpdInd;
        public static bool blnC3ChlnUpdInd;
        public static string strYear;

        public static bool blnC5;
        public static bool blnC9;
        public static DateTime mValidDate;
        
        // DAO/Database Objects (Not directly portable)
        // public static Workspace ws; 
        // public static Database dbeTDS; 
        // public static Recordset rsChln; 
        // ... replaced by EF Core or ADO.NET objects in modern code

        public static int mNoBatches;
        public static bool blnSecondUser;
        public static string strDataBaseName;
        public static string strDatabasePath;

        public static bool blnCreateeTds;
        public static string strPrintForm;
        public static string Y; // Used in NumberToWords (Refactored out, but kept for legacy reference)
        
        public static DateTime mQtrFrom;
        public static DateTime mQtrTO;
        public static DateTime mOpDt;
        public static decimal mTOtalSalRecords; // Currency -> Decimal
        public static decimal mTOtalGrossTOtalIncome;

        public static string No; // Used in NumberToWords
        public static bool mDedErrFound;
        public static bool mChlnErrFound;

        // FileSystemObject replaced by System.IO
        // Excel Objects replaced by OpenXML or EPPlus
        
        public static bool DemoVersion;
        public static string strErrFile;
        public static string strResponseFile;
        public static bool blnDaoDed;
        public static bool blnDaoChallan;
        public static bool blnUnload;
        public static string strChallanSheet;
        public static bool blnDelChallan;
        public static int intEmpNo;
        public static string strExcelFileName;
        public static bool blnIgnoreRate;
        public static bool blnIgnoreFutureDate;
        public static int intPan;
        public static string strActFYear;
        public static string strForm;
    }
}
