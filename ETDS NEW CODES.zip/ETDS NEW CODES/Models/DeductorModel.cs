using System.ComponentModel.DataAnnotations;

namespace EtdsCorrection.Models
{
    public class DeductorModel
    {
        // Based on frmDeductor logic
        
        [Display(Name = "GSTN")]
        [StringLength(15, MinimumLength = 15, ErrorMessage = "GSTN must be 15 characters")]
        public string GSTN { get; set; }

        [Display(Name = "Branch / Division")]
        [StringLength(75)]
        public string Branch { get; set; }

        // Deductor Contact Details
        [Display(Name = "Deductor STD")]
        public string DeductorStdCode { get; set; }
        
        [Display(Name = "Deductor Telephone")]
        public string DeductorPhone { get; set; }
        
        [Display(Name = "Deductor Email")]
        [EmailAddress]
        public string DeductorEmail { get; set; }

        // Responsible Person Alternate Contact
        [Display(Name = "Responsible Person Alternate STD")]
        public string ResponsiblePersonAltStdCode { get; set; }

        [Display(Name = "Responsible Person Alternate Telephone")]
        public string ResponsiblePersonAltPhone { get; set; }

        [Display(Name = "Responsible Person Alternate Email")]
        [EmailAddress]
        public string ResponsiblePersonAltEmail { get; set; }
        
        [Display(Name = "Mobile Number")]
        [StringLength(10)]
        public string MobileNumber { get; set; }

        // Status (Dropdown in VB)
        // Values: Central Government (A), State Government (S), etc.
        public string Status { get; set; }

        public string State { get; set; }

        // Additional fields usually present in Parameter table:
        public string Name { get; set; }
        public string Tan { get; set; }
        public string Pan { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string Address3 { get; set; }
        public string Address4 { get; set; }
        public string Address5 { get; set; }
        public int PinCode { get; set; }
    }
}
