using System;
using System.ComponentModel.DataAnnotations;

namespace EtdsCorrection.Models
{
    public class SalaryModel
    {
        // Based on standard ETDS Salary Record requirements (Form 24Q)
        
        [Key]
        public int Id { get; set; } // Internal ID

        [Required]
        [Display(Name = "Employee PAN")]
        [StringLength(10, MinimumLength = 10)]
        public string EmployeePan { get; set; }

        [Required]
        [Display(Name = "Employee Name")]
        public string EmployeeName { get; set; }

        [Display(Name = "Category of Employee")]
        public string EmployeeCategory { get; set; } // Women, Senior Citizen, etc.

        [DataType(DataType.Date)]
        [Display(Name = "Date of Payment")]
        public DateTime PaymentDate { get; set; }

        [DataType(DataType.Currency)]
        [Display(Name = "Amount Paid / Credited")]
        public decimal AmountPaid { get; set; }

        [DataType(DataType.Currency)]
        [Display(Name = "TDS Deducted")]
        public decimal TdsDeducted { get; set; }

        [DataType(DataType.Currency)]
        [Display(Name = "Surcharge")]
        public decimal Surcharge { get; set; }

        [DataType(DataType.Currency)]
        [Display(Name = "Education Cess")]
        public decimal EducationCess { get; set; }

        [DataType(DataType.Currency)]
        [Display(Name = "Total Tax Deposited")]
        public decimal TotalTaxDeposited { get; set; }

        [Display(Name = "Challan Serial Number")]
        public string ChallanSerialNumber { get; set; }

        [Display(Name = "BSR Code")]
        public string BsrCode { get; set; }

        // Remarks / Reason for lower deduction
        public string ReasonForLowerDeduction { get; set; }
        public string CertificateNumber { get; set; } // If lower deduction
    }
}
