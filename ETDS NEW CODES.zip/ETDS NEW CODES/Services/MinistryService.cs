using System.Collections.Generic;

namespace EtdsCorrection.Models
{
    public class Ministry
    {
        public string Name { get; set; }
        public string Code { get; set; }
    }
}

namespace EtdsCorrection.Services
{
    using EtdsCorrection.Models;

    public static class MinistryService
    {
        public static List<Ministry> GetMinistries()
        {
            return new List<Ministry>
            {
                new Ministry { Name = "Agriculture", Code = "01" },
                new Ministry { Name = "Atomic Energy", Code = "02" },
                new Ministry { Name = "Fertilizers", Code = "03" },
                new Ministry { Name = "Chemicals and Petrochemicals", Code = "04" },
                new Ministry { Name = "Civil Aviation and Tourism", Code = "05" },
                new Ministry { Name = "Coal", Code = "06" },
                new Ministry { Name = "Consumer Affairs, Food and Distribution", Code = "07" },
                new Ministry { Name = "Commerce and Textiles", Code = "08" },
                new Ministry { Name = "Environment and Forests and Ministry of Earth Science", Code = "09" },
                new Ministry { Name = "External Affairs and Overseas Indian Affairs", Code = "10" },
                new Ministry { Name = "Finance", Code = "11" },
                new Ministry { Name = "Central Board of Direct Taxes", Code = "12" },
                new Ministry { Name = "Central Board of Excise and Customs", Code = "13" },
                new Ministry { Name = "Contoller of Aid Accounts and Audit", Code = "14" },
                new Ministry { Name = "Central Pension Accounting Office", Code = "15" },
                new Ministry { Name = "Food Processing Industries", Code = "16" },
                new Ministry { Name = "Health and Family Welfare", Code = "17" },
                new Ministry { Name = "Home Affairs and Development of North Eastern Region", Code = "18" },
                new Ministry { Name = "Human Resource Development", Code = "19" },
                new Ministry { Name = "Industry", Code = "20" },
                new Ministry { Name = "Information and Broadcasting", Code = "21" },
                new Ministry { Name = "Telecommunication and Information Technology", Code = "22" },
                new Ministry { Name = "Labour", Code = "23" },
                new Ministry { Name = "Law and Justice and Company Affairs", Code = "24" },
                new Ministry { Name = "Personnel, Grievances and Pesions", Code = "25" },
                new Ministry { Name = "Petroleum and Natural Gas", Code = "26" },
                new Ministry { Name = "Plannning, Statistics and Programme Implementation", Code = "27" },
                new Ministry { Name = "Power", Code = "28" },
                new Ministry { Name = "New and Renewable Energy", Code = "29" },
                new Ministry { Name = "Rural Development and Panchayati Raj", Code = "30" },
                new Ministry { Name = "Science And Technology", Code = "31" },
                new Ministry { Name = "Space", Code = "32" },
                new Ministry { Name = "Steel", Code = "33" },
                new Ministry { Name = "Mines", Code = "34" },
                new Ministry { Name = "Social Justice and Empowerment", Code = "35" },
                new Ministry { Name = "Tribal Affairs", Code = "36" },
                new Ministry { Name = "D/o Commerce (Supply Division)", Code = "37" },
                new Ministry { Name = "Shipping and Road Transport and Highways", Code = "38" },
                new Ministry { Name = "Urban Development, Urban Employment and Poverty Alleviation", Code = "39" },
                new Ministry { Name = "Water Resources", Code = "40" },
                new Ministry { Name = "President", Code = "41" }, // Fixed missing quote in original VB
                new Ministry { Name = "Lok Sabha Secretariat", Code = "42" },
                new Ministry { Name = "Rajya Sabha secretariat", Code = "43" },
                new Ministry { Name = "Election Commission", Code = "44" },
                new Ministry { Name = "Ministry of Defence (Controller General of Defence Accounts)", Code = "45" },
                new Ministry { Name = "Ministry of Railways", Code = "46" },
                new Ministry { Name = "Department of Posts", Code = "47" },
                new Ministry { Name = "Department of Telecommunications", Code = "48" },
                new Ministry { Name = "Andaman and Nicobar Islands Administration", Code = "49" },
                new Ministry { Name = "Chandigarh Administration", Code = "50" },
                new Ministry { Name = "Dadra and Nagar Haveli", Code = "51" },
                new Ministry { Name = "Goa, Daman and Diu", Code = "52" },
                new Ministry { Name = "Lakshadweep", Code = "53" },
                new Ministry { Name = "Pondicherry Administration", Code = "54" },
                new Ministry { Name = "Pay and Accounts Officers (Audit)", Code = "55" },
                new Ministry { Name = "Ministry of Non-conventional energy sources", Code = "56" },
                new Ministry { Name = "Government Of NCT of Delhi", Code = "57" },
                new Ministry { Name = "Others", Code = "99" }
            };
        }
    }
}
